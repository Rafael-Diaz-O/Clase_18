
package Universidad;





public class UndergraduarteStudent extends Student {
    
    //Atrivutos 
    
    private String mejorField;
    private int academicYear;
    
    //Metodos 
    /*
    public void setMejorField (String Field){
        this.mejorField = mejorField;
        
    }
    
    public void setAcademicYear (String Year ){
        
        this.academicYear = academicYear;
        
    }
    
    public String getMejorField(){
        return this.mejorField;
        
    }
    
    public String getAcademicYear (){
        return this.academicYear; 
        
    }
    
    
    
    
    @voerride 
    
    public  String toString(){
        
        String str = super.toString() + "\nMajor Field: " + this.getMejorField()
        
        
        
        return; 
    }
    */ 
}
