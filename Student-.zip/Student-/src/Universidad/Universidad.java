
package Universidad;


public class Universidad {
    
    public static void main (String[] ars){
        
        GraduateStudent megradue = new  GraduateStudent();
        
        megradue.setName("Derek");
        megradue.setEmail("anonimo@gmail");
        megradue.setStudent(234546457);
        megradue.setGpa(5.0);
        megradue.setUndergraduadeDegree("Ing");
        megradue.setUndergraduateInstitution("UIS");
        
        
        
        System.out.println("Info " + megradue.toString());
     
        
      
        
    }
    
}
