package Universidad;


public class Student {
    
    
    //Atrivutos 
    
    private String name; 
    private String email;
    private int student;
    private double gpa ; 
    
    
    //Metodos 
    
    
    public Student(){
        this.name = null;
        this.email = null;
        this.student = 0;
        this.gpa = 0; 
    }
    
    public Student (String name, String email, int student , double gpa ){
        
        this.name = name;
        this.email = email;
        this.student = student; 
        this.gpa = gpa; 
        
        
    }
            

    public void setName (String name ) {
        
        this.name = name;
    
}
    
    public void setEmail (String email){
        this.email = email;
        
        
    }
    
    public void setStudent (int Student){
        this.student = Student;
        
    }
    
    public void setGpa (double gpa){
        this.gpa = gpa; 
    }
    public String getName(){
        return this.name; 
        
    }
    
    public String getEmail(){
        return this.email;
        
        
    }
    
    public int getStdent(){
        return this.student;
        
    }
    
    public double getGpa(){
        return this.gpa; 
        
    }
    
    
    
  
   
       
        
        
        @Override 
        
        public String toString (){
            
            String str = "Student info \n " + "Name: " + this.getName() + "\n Student: "+
                    this.getStdent() + "\n GPA: " + this.getGpa();
            
            return str; 
        
        
    
        
        
    }
}
