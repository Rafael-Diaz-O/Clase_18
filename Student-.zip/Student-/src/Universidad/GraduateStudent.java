
package Universidad;


public class GraduateStudent extends Student {
    
    //Atrivutos 
    
    private String undergraduateDegre;
    private String undergraduateInstitution; 
    
    //Metodos
    
    public void setUndergraduadeDegree (String degree){
        this.undergraduateDegre = degree ;
    }
    
    public void setUndergraduateInstitution (String institution){
        this.undergraduateInstitution = institution;  
        
    }
    
    public String getUndergraduateIntitution (){
        return this.undergraduateInstitution;
        
    } 
    
   public String getUndergraduateDegree(){
       return this.undergraduateDegre; 
       
   }
    
    
@Override 

public  String toString() {
    String str = super.toString() + "\n Datos:  " + "\n Degree: " + this.getUndergraduateDegree() +
            "\n Intitution: " + this.getUndergraduateIntitution();
    return str; 
    
}
    
    
    
    
}
